       Nombre        |     Rol     | Paralelo 
Nelson Sepúlveda     | 202004610-7 |   200
Vicente Henríquez    | 202051507-7 |   200 

Instrucciones:
	- Se deben abrir 2 terminales que lleven a cada carpeta de los archivos por separado,
	  en nuestro caso es a la carpeta Client y Server
	
	- Luego para ejecutar, primero se debe escribir el comando "go run main.go" en la terminal
	  de Server y segundo en la de Client, para así comenzar la ejecución de la trivia