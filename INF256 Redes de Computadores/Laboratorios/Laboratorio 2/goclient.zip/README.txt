GOCLIENT
--------------------------------
Juan Cucurella / Nicolás Rodríguez
--------------------------------
Instrucciones:

- Descomprimir el proyecto en el directorio de trabajo del laboratorio
- Moverse a la carpeta GoClient:

    $ cd ./goclient

- Ejecutar los siguientes comandos para inicializar el módulo e instalar las dependencias:

    $ go mod init github.com/goclient

    $ go mod tidy

- Modificar el código de manera que los datos correspondan a su grupo de trabajo y se realice la interacción esperada

- Ejecutar el programa:

    $ go run main.go

--------------------------------
REQUERIMIENTOS
--------------------------------
- Go versión 1.22+