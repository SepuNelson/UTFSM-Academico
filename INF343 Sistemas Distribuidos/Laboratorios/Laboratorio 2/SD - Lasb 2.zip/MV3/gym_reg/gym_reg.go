package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"time"
	"encoding/json"
	"math"
	"math/rand"

	pb "gym_reg/proto/grpc-server/proto"

	"google.golang.org/grpc"
)

/*
Variables and List Definitions:
- combates: Lista de combates recibidos.
*/

// Lista global de combates recibidos
var combates = []*pb.Combate{}

/*
Structs Definitions:
- servidorGYMREG: Estructura del servidor gRPC.
- Combate: Estructura para los combates.
*/

// Estructura del servidor CDP
type servidorGYMREG struct {
	pb.UnimplementedGYMREGServiceServer
}

type Combate struct {
	CombateID   int32
	TorneoID    int32
	Entrenador1 *pb.Trainer
	Entrenador2 *pb.Trainer
	Estado      string // "pendiente", "finalizado", etc.
}

type MensajeResultado struct {
    TorneoID         int32  `json:"torneo_id"`
    IdEntrenador1    int32 `json:"id_entrenador_1"`
    NombreEntrenador1 string `json:"nombre_entrenador_1"`
    IdEntrenador2    int32 `json:"id_entrenador_2"`
    NombreEntrenador2 string `json:"nombre_entrenador_2"`
    IdGanador        int32 `json:"id_ganador"`
    NombreGanador    string `json:"nombre_ganador"`
    Fecha            string `json:"fecha"`
    TipoMensaje      string `json:"tipo_mensaje"`
}

/*
Local Functions Definitions:
- ejecutarCombates: Función para ejecutar los combates.
*/

func ejecutarCombates(entrenador1, entrenador2 *pb.Trainer) (entrenador *pb.Trainer) {

	// Tiempo para que no se ejecute todo inmediatamente
	time.Sleep(5 * time.Second)

	// Simulación de combate entre dos entrenadores
	diff := float64(entrenador1.Ranking - entrenador2.Ranking)
    k := 100.0
    prob := 1.0 / (1.0 + math.Exp(-diff/k))
    if rand.Float64() <= prob {

		// Cambio de Estado
		entrenador1.Estado = pb.EstadoEntrenador_ESPERANDO_RESULTADO
        return entrenador1
    }

	// Cambio de Estado
	entrenador2.Estado = pb.EstadoEntrenador_ESPERANDO_RESULTADO
	return entrenador2
}

/*
gRPC Functions Definitions:
- RecepcionCombate: Método gRPC para recibir combates.
*/

// Implementación del método gRPC RecepcionCombate
func (s *servidorGYMREG) AsignarCombate(ctx context.Context, req *pb.Combate) (*pb.Response, error) {
	// Guardar el combate recibido
	combates = append(combates, req)
	fmt.Printf("Combate recibido: ID %d, Torneo %d, Entrenadores: %s vs %s\n",
		req.CombateId, req.TorneoId, req.Entrenador1.Nombre, req.Entrenador2.Nombre)

	// Cambiar estado a "En Combate"
	req.Entrenador1.Estado = pb.EstadoEntrenador_EN_COMBATE
	req.Entrenador2.Estado = pb.EstadoEntrenador_EN_COMBATE
	
	// Ejecutar el combate
	entrenador_ganador := ejecutarCombates(req.Entrenador1, req.Entrenador2)

	mensaje := MensajeResultado{
        TorneoID:          req.TorneoId,
        IdEntrenador1:     req.Entrenador1.Id,
        NombreEntrenador1: req.Entrenador1.Nombre,
        IdEntrenador2:     req.Entrenador2.Id,
        NombreEntrenador2: req.Entrenador2.Nombre,
        IdGanador:         entrenador_ganador.Id,
        NombreGanador:     entrenador_ganador.Nombre,
        Fecha:             time.Now().Format("2006-01-02"),
        TipoMensaje:       "resultado_combate",
    }

	fmt.Printf("Resultado del combate: %s vs %s, Ganador: %s\n",
		req.Entrenador1.Nombre, req.Entrenador2.Nombre, entrenador_ganador.Nombre)
	
	// Serializar a JSON
	_, err := json.MarshalIndent(mensaje, "", "  ")
	if err != nil {
		fmt.Println("Error serializando:", err)
		return nil, err
	}

	return &pb.Response{Mensaje: "Combate recibido correctamente"}, nil
}

func main() {
	lis, err := net.Listen("tcp", ":50052")
	if err != nil {
		log.Fatalf("Error al escuchar: %v", err)
	}
	grpcServer := grpc.NewServer()
	pb.RegisterGYMREGServiceServer(grpcServer, &servidorGYMREG{})
	fmt.Println("CDP Server is running in port 50052...")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("Fallo al servir: %v", err)
	}
}