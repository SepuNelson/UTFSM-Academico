# DevContainer - ETL Fan Engagement Pipeline

Este workspace está configurado para trabajar con un pipeline ETL completo que incluye Apache Airflow, Apache Beam, Kafka y MinIO.

## 🚀 Inicio Rápido

1. **Abrir en DevContainer**: Abre este proyecto en VS Code y selecciona "Reopen in Container" cuando se te solicite.

2. **Esperar la inicialización**: El contenedor se configurará automáticamente y ejecutará el script `setup-workspace.sh`.

3. **Acceder a los servicios**: Una vez que todos los servicios estén listos, podrás acceder a:

## 🌐 Servicios Disponibles

### Airflow Web UI
- **URL**: http://localhost:8081
- **Usuario**: `airflow`
- **Contraseña**: `airflow`
- **Descripción**: Interfaz web para gestionar y monitorear DAGs

### Kafka UI
- **URL**: http://localhost:8080
- **Descripción**: Interfaz web para explorar topics, mensajes y configuración de Kafka

### MinIO
- **URL**: http://localhost:9000
- **Console**: http://localhost:9001
- **Usuario**: `minio-root-user`
- **Contraseña**: `minio-root-password`
- **Descripción**: Almacenamiento de objetos compatible con S3

### Kafka Broker
- **URL**: localhost:9092 (externo)
- **URL**: localhost:29092 (Docker)
- **Descripción**: Broker de Kafka para streaming de datos

## 📁 Estructura del Proyecto

```
workspace/
├── .devcontainer/          # Configuración del contenedor de desarrollo
├── dags/                   # DAGs de Airflow
├── data/                   # Datos de entrada
├── output/                 # Datos procesados
├── schemas/                # Esquemas Avro
├── src/                    # Código fuente
│   ├── beam/              # Pipelines de Apache Beam
│   └── settings.py        # Configuraciones
├── logs/                   # Logs de Airflow
└── plugins/                # Plugins de Airflow
```

## 🔧 Comandos Útiles

### Verificar estado de servicios
```bash
# Ver contenedores ejecutándose
docker ps

# Ver logs de Airflow
docker logs ws-airflow-webserver
docker logs ws-airflow-scheduler

# Ver logs de Kafka
docker logs ws-kafka
```

### Ejecutar pipeline manualmente
```bash
python src/beam/fan_engagement_etl.py \
    --input data/fan_engagement.jsonl \
    --output output/fan_engagement \
    --schema schemas/fan_engagement_schema.json
```

### Ejecutar pruebas
```bash
python test_pipeline.py
```

### Reiniciar servicios
```bash
docker-compose -f .devcontainer/docker-compose.yml restart
```

## 🐛 Solución de Problemas

### Los servicios no están disponibles
1. Verifica que todos los contenedores estén ejecutándose: `docker ps`
2. Revisa los logs: `docker logs <nombre-contenedor>`
3. Reinicia los servicios si es necesario

### Error de permisos en Airflow
1. Verifica que los directorios `dags/`, `logs/` y `plugins/` tengan los permisos correctos
2. Reinicia el contenedor de inicialización: `docker restart ws-airflow-init`

### Problemas de conectividad con Kafka
1. Verifica que Zookeeper esté ejecutándose: `docker logs ws-zookeeper`
2. Verifica que Kafka esté listo: `docker logs ws-kafka`
3. Espera unos minutos a que todos los servicios se inicialicen completamente

## 📚 Recursos Adicionales

- [Documentación de Apache Airflow](https://airflow.apache.org/docs/)
- [Documentación de Apache Beam](https://beam.apache.org/documentation/)
- [Documentación de Apache Kafka](https://kafka.apache.org/documentation/)
- [Documentación de MinIO](https://docs.min.io/)

## 🔄 Flujo de Trabajo

1. **Desarrollo**: Modifica los DAGs en `dags/` o los pipelines en `src/beam/`
2. **Pruebas**: Ejecuta `python test_pipeline.py` para verificar cambios
3. **Despliegue**: Los DAGs se cargan automáticamente en Airflow
4. **Monitoreo**: Usa la UI de Airflow para monitorear ejecuciones
5. **Notificaciones**: Los resultados se envían automáticamente a Kafka

## ⚠️ Notas Importantes

- Los servicios pueden tardar varios minutos en inicializarse completamente
- Los datos se procesan diariamente a las 2:00 AM según la configuración del DAG
- Los logs de Airflow se almacenan en el directorio `logs/`
- Los datos procesados se almacenan en el directorio `output/` 