# Tarea 3 - ETL Fan Engagement HRL

## Descripción

Este workspace implementa una ETL (Extract, Transform, Load) para convertir datos de participación de fans de la Liga de Carreras de Helicópteros (HRL) de formato JSON a Avro, utilizando Apache Beam y la orquestación con Apache Airflow.

## Consideraciones
En nuestro DAG primero cargamos en el bucket el archivo local si esque hay. por lo tanto en la notificacion de kafka el output estará si o si en el bucket.
El bucket se iniciará vacio en la primera ejecucion. si se ejecuta nuevamente y por alguna razón se sube un archivo .jsonl al input lo procesará.

## Instrucciones de Ejecución

### 1. Iniciar el Workspace

1. Abrir el proyecto en Visual Studio Code
2. Cuando se solicite, hacer clic en "Reopen in Container"
3. Esperar a que se construya el contenedor de desarrollo

### 2. Iniciar Apache Airflow

Apache Airflow se ejecuta localmente. Para iniciarlo, ingresa en la terminal:

```bash
airflow scheduler
```

### 3. Acceder a Airflow

1. Abrir el navegador y ir a: `http://localhost:8081`

### 4. Ejecutar el DAG

1. En la interfaz de Airflow, buscar el DAG `fan_engagement_etl_dag`
2. Hacer clic en el botón "Play" para ejecutar manualmente
3. O esperar a que se ejecute automáticamente a las 00:00 AM diariamente

### 5. Ingresar en MinIO 
1. Ingresar a `http://localhost:9001/` con las credenciales:
  usuario = minio-root-user
  password = minio-root-password

### 5. Monitorear la Ejecución

1. Hacer clic en el DAG para ver los detalles
2. Verificar que ambas tareas se completen exitosamente:
   - `run_beam_pipeline`: Ejecuta la ETL de Beam
   - `send_kafka_notification`: Envía notificación a Kafka

### 6. Verificar Resultados

1. **Archivos Avro**: Los archivos de salida se generan en `output/`, o en el bucket de MinIO
2. **Notificaciones Kafka**: Verificar en Kafka UI (`http://localhost:8083`) el tópico `fan_engagement_notifications`






