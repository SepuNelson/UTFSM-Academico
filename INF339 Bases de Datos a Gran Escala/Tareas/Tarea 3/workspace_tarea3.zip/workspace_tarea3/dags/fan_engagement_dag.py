from __future__ import annotations
import os
import sys
import json
import logging
from datetime import datetime, timedelta

from airflow.models.dag import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.amazon.aws.operators.s3 import S3CreateBucketOperator
from airflow.providers.amazon.aws.transfers.local_to_s3 import LocalFilesystemToS3Operator
from airflow.utils.dates import days_ago
from airflow.exceptions import AirflowException

sys.path.append('/workspaces/workspace_tarea3/src')
from settings import KAFKA_BROKERS, KAFKA_TOPIC, MINIO_ENDPOINT, MINIO_ACCESS_KEY, MINIO_SECRET_KEY

# --- Constantes del DAG ---
AWS_CONN_ID = "minio-conn"
BUCKET_NAME = "fan-engagement-bucket"
LOCAL_INPUT_FILE = "/workspaces/workspace_tarea3/data/fan_engagement.jsonl"
LOCAL_SCHEMA_FILE = "/workspaces/workspace_tarea3/schemas/fan_engagement_schema.json"
S3_INPUT_KEY = "input/fan_engagement.jsonl"
S3_SCHEMA_KEY = "schemas/fan_engagement_schema.json"
S3_OUTPUT_KEY = "output/"
S3_OUTPUT_PATTERN = f"s3://{BUCKET_NAME}/{S3_OUTPUT_KEY}fan_engagement-*"
KAFKA_NOTIFICATION_LOCATION = f"s3://{BUCKET_NAME}/{S3_OUTPUT_KEY}"


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': days_ago(1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'aws_conn_id': AWS_CONN_ID
}

# --- Funciones personalizadas del DAG ---
def check_output_files_in_s3():
    """Verifica si los archivos de salida existen en el bucket de S3."""
    hook = S3Hook(aws_conn_id=AWS_CONN_ID)
    files = hook.list_keys(bucket_name=BUCKET_NAME, prefix=S3_OUTPUT_KEY)
    avro_files = [f for f in files if f.endswith('.avro')]
    if not avro_files:
        raise AirflowException(f"No se encontraron archivos Avro de salida en s3://{BUCKET_NAME}/{S3_OUTPUT_KEY}")
    return f"Se encontraron {len(avro_files)} archivos de salida."

def send_kafka_notification(**context):
    """Envía una notificación a Kafka sobre la finalización del pipeline."""
    from kafka import KafkaProducer
    
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKERS,
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
        retries=3,
        acks='all'
    )
    
    notification_message = {
        "event_type": "data_processing_completed",
        "data_entity": "FanEngagement",
        "status": "success",
        "location": KAFKA_NOTIFICATION_LOCATION,
        "processed_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "source_system": context['dag'].dag_id,
        "dag_run_id": context['dag_run'].run_id
    }
    
    producer.send(KAFKA_TOPIC, notification_message)
    producer.flush()
    producer.close()
    
    return "Notificacion enviada."

# --- Definición del DAG ---
with DAG(
    dag_id='fan_engagement_etl_dag',
    default_args=default_args,
    description='ETL para procesar datos de Fan Engagement desde S3 y notificando a Kafka.',
    schedule_interval='@daily',
    catchup=False,
    tags=['fan-engagement', 's3', 'kafka', 'beam'],
) as dag:

    create_s3_bucket = S3CreateBucketOperator(
        task_id="create_s3_bucket",
        bucket_name=BUCKET_NAME,
    )

    upload_input_data_to_s3 = LocalFilesystemToS3Operator(
        task_id="upload_input_data_to_s3",
        filename=LOCAL_INPUT_FILE,
        dest_key=S3_INPUT_KEY,
        dest_bucket=BUCKET_NAME,
        replace=True,
    )
    
    upload_schema_to_s3 = LocalFilesystemToS3Operator(
        task_id="upload_schema_to_s3",
        filename=LOCAL_SCHEMA_FILE,
        dest_key=S3_SCHEMA_KEY,
        dest_bucket=BUCKET_NAME,
        replace=True,
    )

    run_beam_pipeline = BashOperator(
        task_id='run_beam_pipeline',
        bash_command=f"""
        set -e
        set -x
        /usr/local/python/3.12.10/bin/python3 /workspaces/workspace_tarea3/src/beam/fan_engagement_etl.py \
            --input s3://{BUCKET_NAME}/{S3_INPUT_KEY} \
            --output s3://{BUCKET_NAME}/{S3_OUTPUT_KEY}fan_engagement \
            --schema s3://{BUCKET_NAME}/{S3_SCHEMA_KEY} \
            --runner=DirectRunner \
            --temp_location=s3://{BUCKET_NAME}/temp \
            --project=dev \
            --s3_endpoint_url=http://{MINIO_ENDPOINT} \
            --s3_access_key_id={MINIO_ACCESS_KEY} \
            --s3_secret_access_key={MINIO_SECRET_KEY} \
        """,
    )

    check_s3_output = PythonOperator(
        task_id='check_output_files_in_s3',
        python_callable=check_output_files_in_s3,
    )

    send_completion_notification = PythonOperator(
        task_id='send_kafka_notification',
        python_callable=send_kafka_notification,
    )

    create_s3_bucket >> [upload_input_data_to_s3, upload_schema_to_s3] 
    [upload_input_data_to_s3, upload_schema_to_s3] >> run_beam_pipeline
    run_beam_pipeline >> check_s3_output >> send_completion_notification 