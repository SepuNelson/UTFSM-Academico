import apache_beam as beam
import json
from datetime import datetime
import argparse
import logging
import os
from apache_beam.options.pipeline_options import PipelineOptions

class ParseJsonAndTransform(beam.DoFn):
    def process(self, element):
        data = json.loads(element)
        timestamp_str = data.get('Timestamp', '')
        if timestamp_str:
            dt = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
            timestamp_unix = int(dt.timestamp() * 1000)
        else:
            timestamp_unix = None

        yield {
            'FanID': data.get('FanID'),
            'RaceID': data.get('RaceID'),
            'Timestamp': timestamp_str,
            'Timestamp_unix': timestamp_unix,
            'ViewerLocationCountry': data.get('ViewerLocationCountry'),
            'DeviceType': data.get('DeviceType'),
            'EngagementMetric_secondswatched': data.get('EngagementMetric_secondswatched'),
            'PredictionClicked': data.get('PredictionClicked'),
            'MerchandisingClicked': data.get('MerchandisingClicked')
            }


def run(argv=None):
    """
    Define y ejecuta el pipeline de Apache Beam.
    Este pipeline lee desde una fuente (local o S3), transforma los datos,
    y escribe el resultado en formato Avro tanto en S3 como localmente.
    """
    parser = argparse.ArgumentParser(description='ETL Pipeline de Beam para Fan Engagement')
    parser.add_argument('--input', required=True, help='Ruta del archivo de entrada (JSONL). Puede ser local o s3://')
    parser.add_argument('--output', required=True, help='Prefijo para los archivos de salida (Avro). Puede ser local o s3://')
    parser.add_argument('--schema', required=True, help='Ruta al archivo de esquema Avro (JSON). Puede ser local o s3://')
    parser.add_argument('--local_output', help='Prefijo para los archivos de salida locales (opcional)')
    
    # Agregar argumentos para configuración de S3/MinIO
    parser.add_argument('--s3_endpoint_url', help='URL del endpoint de S3 (para MinIO)')
    parser.add_argument('--s3_access_key_id', help='Access Key ID para S3')
    parser.add_argument('--s3_secret_access_key', help='Secret Access Key para S3')
    
    # Parsea los argumentos conocidos para el pipeline y deja el resto para Beam
    known_args, pipeline_args = parser.parse_known_args(argv)

    # Configurar las variables de entorno AWS para Apache Beam
    if known_args.s3_access_key_id:
        os.environ['AWS_ACCESS_KEY_ID'] = known_args.s3_access_key_id
        
    if known_args.s3_secret_access_key:
        os.environ['AWS_SECRET_ACCESS_KEY'] = known_args.s3_secret_access_key
        
    if known_args.s3_endpoint_url:
        os.environ['AWS_ENDPOINT_URL'] = known_args.s3_endpoint_url

    # Crear las opciones del pipeline
    pipeline_options = PipelineOptions(pipeline_args)

    # Configurar output local por defecto si no se especifica
    if not known_args.local_output:
        # Crear la carpeta output si no existe
        local_output_dir = '/workspaces/workspace_tarea3/output'
        os.makedirs(local_output_dir, exist_ok=True)
        known_args.local_output = os.path.join(local_output_dir, 'fan_engagement')

    # Leer el esquema usando un enfoque más directo para S3
    avro_schema = None
    if known_args.schema.startswith('s3://'):
        # Para rutas S3, usar boto3 directamente ya que es más confiable
        try:
            import boto3
            from urllib.parse import urlparse
            
            # Parsear la URL S3
            parsed_url = urlparse(known_args.schema)
            bucket_name = parsed_url.netloc
            key = parsed_url.path.lstrip('/')
            
            # Configurar cliente boto3
            session = boto3.Session(
                aws_access_key_id=known_args.s3_access_key_id,
                aws_secret_access_key=known_args.s3_secret_access_key
            )
            
            s3_client = session.client(
                's3',
                endpoint_url=known_args.s3_endpoint_url
            )
            
            # Leer el archivo de esquema
            response = s3_client.get_object(Bucket=bucket_name, Key=key)
            schema_content = response['Body'].read().decode('utf-8')
            avro_schema = json.loads(schema_content)
            
            logging.info(f"Esquema leído exitosamente desde S3: {known_args.schema}")
            
        except Exception as e:
            logging.error(f"Error leyendo esquema desde S3 con boto3: {e}")
            raise
    else:
        with open(known_args.schema, 'r') as f:
            avro_schema = json.load(f)

    if not avro_schema:
        raise ValueError(f"No se pudo cargar el esquema desde {known_args.schema}")

    # Ejecutar el pipeline con escritura dual (S3 y local)
    with beam.Pipeline(options=pipeline_options) as p:
        # Leer y transformar los datos
        transformed_data = (
            p
            | 'ReadInputData' >> beam.io.ReadFromText(known_args.input)
            | 'ParseAndTransform' >> beam.ParDo(ParseJsonAndTransform())
        )
        (
            transformed_data
            | 'WriteToS3' >> beam.io.WriteToAvro(
                known_args.output,
                schema=avro_schema,
                file_name_suffix='.avro',
                use_fastavro=True
            )
        )
        (
            transformed_data
            | 'WriteToLocal' >> beam.io.WriteToAvro(
                known_args.local_output,
                schema=avro_schema,
                file_name_suffix='.avro',
                use_fastavro=True
            )
        )
    


if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()