#!/bin/bash
pip install --upgrade pip
pip install -r requirements.txt
# Instalar Apache Airflow
chmod +x scripts/install-airflow.sh
./scripts/install-airflow.sh

