#!/bin/bash
# Crear directorios necesarios si no existen
mkdir -p logs plugins output

sleep 10  # Esperar a que Kafka esté listo

# Verificar si el topic existe y crearlo si es necesario
docker exec ws-kafka kafka-topics --bootstrap-server localhost:19092 --list | grep -q "fan_engagement_notifications" || {
    echo "Creando topic fan_engagement_notifications..."
    docker exec ws-kafka kafka-topics --bootstrap-server localhost:19092 --create --topic fan_engagement_notifications --partitions 1 --replication-factor 1
}

chmod +x scripts/install-dependencies.sh
./scripts/install-dependencies.sh
